package questoestrab;

public class Vestuario {

}
