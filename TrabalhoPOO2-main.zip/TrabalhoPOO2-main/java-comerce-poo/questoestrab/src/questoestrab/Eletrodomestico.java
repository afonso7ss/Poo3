package questoestrab;

public class Eletrodomestico {

}
