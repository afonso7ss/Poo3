package questoestrab;

public class Pedido {

}
