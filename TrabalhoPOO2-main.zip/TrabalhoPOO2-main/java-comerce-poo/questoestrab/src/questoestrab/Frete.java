package questoestrab;

public interface Frete {
	public float CalcularFrete();
}
