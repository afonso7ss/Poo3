package questoestrab;

public class Sistema {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
